export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  image?: string; // Base64 string
  timestamp: number;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  hasStarted: boolean; // To toggle between Hero view and Chat view
}

export interface UserInput {
  text: string;
  image: string | null;
}
