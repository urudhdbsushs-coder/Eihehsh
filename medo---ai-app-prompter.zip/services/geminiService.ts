import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Initialize the client with the environment variable API key.
// The key is injected automatically from the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateGeminiResponse = async (
  prompt: string,
  imageBase64: string | null
): Promise<string> => {
  try {
    let response: GenerateContentResponse;

    if (imageBase64) {
      // Multimodal Request (Image + Text)
      // Use gemini-2.5-flash-image for image understanding
      const base64Data = imageBase64.split(',')[1];
      const mimeType = imageBase64.substring(imageBase64.indexOf(':') + 1, imageBase64.indexOf(';'));

      response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: mimeType || 'image/png',
                data: base64Data,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      });
    } else {
      // Text-only Request
      // Use gemini-3-flash-preview for high-quality text generation and reasoning
      response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: "You are MeDo, an expert AI product consultant and developer. Your goal is to help users ideate, specify, and refine application concepts. You provide structured, insightful, and technical feedback. When asked for ideas, be innovative. When asked for code, provide clean, modern snippets.",
        }
      });
    }

    return response.text || "I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, something went wrong while connecting to the AI service. Please check your connection.";
  }
};