import React, { useState } from 'react';
import { Header } from './components/Header';
import { PromptInput } from './components/PromptInput';
import { ChatInterface } from './components/ChatInterface';
import { generateGeminiResponse } from './services/geminiService';
import { ChatState, Message } from './types';
import { Sparkles, Rocket } from 'lucide-react';

export default function App() {
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    hasStarted: false,
  });

  const handleSend = async (text: string, image: string | null) => {
    if (!text && !image) return;

    const newUserMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: text,
      image: image || undefined,
      timestamp: Date.now(),
    };

    // Update UI immediately with user message
    setChatState((prev) => ({
      ...prev,
      hasStarted: true,
      isLoading: true,
      messages: [...prev.messages, newUserMessage],
    }));

    // Call API
    const responseText = await generateGeminiResponse(text, image);

    const newModelMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText,
      timestamp: Date.now(),
    };

    setChatState((prev) => ({
      ...prev,
      isLoading: false,
      messages: [...prev.messages, newModelMessage],
    }));
  };

  return (
    <div className="min-h-screen bg-slate-50 relative overflow-hidden font-sans text-slate-900 selection:bg-indigo-100 selection:text-indigo-700">
      
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
         {/* Top Gradient */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-purple-200/40 rounded-full blur-[120px]" />
        <div className="absolute top-[-5%] right-[-10%] w-[40%] h-[40%] bg-blue-200/40 rounded-full blur-[100px]" />
        
        {/* Dot Pattern Overlay */}
        <div className="absolute inset-0 opacity-[0.4]" style={{
            backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)',
            backgroundSize: '24px 24px'
        }}></div>
      </div>

