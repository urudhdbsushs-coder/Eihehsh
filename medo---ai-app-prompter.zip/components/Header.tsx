import React from 'react';
import { Menu, Zap } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 p-4 flex justify-between items-center z-50 bg-transparent">
      {/* Logo Area */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg">
          M
        </div>
        <span className="text-xl font-bold text-slate-800">MeDo</span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-4">
        {/* Credits Pill */}
        <div className="hidden sm:flex items-center gap-1 bg-white/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-purple-100 shadow-sm text-indigo-600 font-semibold">
          <span className="text-sm">550</span>
        </div>

        {/* User Avatar */}
        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-200 to-indigo-200 p-0.5 cursor-pointer hover:scale-105 transition-transform">
           <img 
            src="https://picsum.photos/100/100" 
            alt="User" 
            className="w-full h-full rounded-full object-cover border-2 border-white"
           />
        </div>

        {/* Menu Button */}
        <button className="p-2 text-slate-700 hover:bg-white/50 rounded-full transition-colors">
          <Menu size={24} />
        </button>
      </div>
    </header>
  );
};
