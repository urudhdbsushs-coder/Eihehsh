import React, { useEffect, useRef } from 'react';
import { Message } from '../types';
import ReactMarkdown from 'react-markdown';

interface ChatInterfaceProps {
  messages: Message[];
  isLoading: boolean;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isLoading }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto px-4 pb-32 pt-24 max-w-4xl mx-auto w-full scrollbar-hide">
      {messages.map((msg) => (
        <div 
          key={msg.id} 
          className={`flex mb-8 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div className={`max-w-[85%] sm:max-w-[75%] flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            
            {/* Avatar for Assistant */}
            {msg.role === 'model' && (
              <div className="mb-2 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                  AI
                </div>
                <span className="text-sm font-medium text-slate-500">MeDo</span>
              </div>
            )}

            <div 
              className={`
                p-4 sm:p-6 rounded-2xl shadow-sm
                ${msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-br-none' 
                  : 'bg-white border border-slate-100 text-slate-700 rounded-bl-none'}
              `}
            >
              {msg.image && (
                <img 
                  src={msg.image} 
                  alt="User uploaded" 
                  className="max-w-full h-auto rounded-lg mb-3 border border-white/20" 
                  style={{ maxHeight: '300px'}}
                />
              )}
              <div className="prose prose-sm sm:prose-base max-w-none break-words">
                 {msg.role === 'user' ? (
                   <p className="whitespace-pre-wrap">{msg.text}</p>
                 ) : (
                   <ReactMarkdown>{msg.text}</ReactMarkdown>
                 )}
              </div>
            </div>
          </div>
        </div>
      ))}

      {isLoading && (
        <div className="flex justify-start mb-8">
           <div className="flex flex-col items-start max-w-[75%]">
             <div className="mb-2 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                  AI
                </div>
                <span className="text-sm font-medium text-slate-500">MeDo</span>
              </div>
              <div className="bg-white border border-slate-100 p-6 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-2">
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
           </div>
        </div>
      )}
      <div ref={bottomRef} />
    </div>
  );
};
