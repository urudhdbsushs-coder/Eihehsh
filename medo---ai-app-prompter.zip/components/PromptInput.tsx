import React, { useState, useRef, useEffect } from 'react';
import { Image as ImageIcon, Folder, SlidersHorizontal, Mic, Send, X, Loader2 } from 'lucide-react';

interface PromptInputProps {
  onSend: (text: string, image: string | null) => void;
  isLoading: boolean;
  compactMode?: boolean;
}

export const PromptInput: React.FC<PromptInputProps> = ({ onSend, isLoading, compactMode = false }) => {
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [inputText]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = () => {
    if ((inputText.trim() || selectedImage) && !isLoading) {
      onSend(inputText, selectedImage);
      setInputText('');
      setSelectedImage(null);
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleSpeech = () => {
    // Simple browser-based speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      if (isListening) return; // Stop handled by end event usually, but simpler here
      
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(prev => prev + (prev ? ' ' : '') + transcript);
      };
      
      recognition.start();
    } else {
      alert("Speech recognition is not supported in this browser.");
    }
  };

  return (
    <div className={`w-full max-w-3xl mx-auto transition-all duration-500 ease-in-out ${compactMode ? 'mb-4' : ''}`}>
      <div className={`
        relative bg-white rounded-[2rem] shadow-[0_8px_30px_rgb(0,0,0,0.08)] 
        border border-white/50 backdrop-blur-xl p-4 transition-all duration-300
        focus-within:shadow-[0_8px_40px_rgb(99,102,241,0.15)] focus-within:border-indigo-100
      `}>
        
        {/* Image Preview Area */}
        {selectedImage && (
          <div className="relative mb-4 inline-block">
            <img src={selectedImage} alt="Upload" className="h-24 w-auto rounded-xl border border-slate-200 shadow-sm object-cover" />
            <button 
              onClick={() => setSelectedImage(null)}
              className="absolute -top-2 -right-2 bg-slate-800 text-white rounded-full p-1 hover:bg-red-500 transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {/* Text Input */}
        <textarea
          ref={textareaRef}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Share your ideas, and I'll make it happen..."
          rows={1}
          className="w-full bg-transparent text-slate-800 placeholder-slate-400 text-lg outline-none resize-none max-h-40 overflow-y-auto"
          style={{ minHeight: '3rem' }}
        />

        {/* Toolbar */}
        <div className="flex justify-between items-center mt-3 pt-2">
          
          <div className="flex items-center gap-2">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
              title="Upload Image"
            >
              <ImageIcon size={22} />
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
              />
            </button>
            <button className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all">
              <Folder size={22} />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all">
              <SlidersHorizontal size={22} />
            </button>
            
            <button 
              onClick={toggleSpeech}
              className={`p-2.5 rounded-xl transition-all ${isListening ? 'text-red-500 bg-red-50 animate-pulse' : 'text-slate-500 hover:text-indigo-600 hover:bg-indigo-50'}`}
            >
              <Mic size={22} />
            </button>

            <button 
              onClick={handleSend}
              disabled={isLoading || (!inputText.trim() && !selectedImage)}
              className={`
                ml-2 p-3 rounded-xl flex items-center justify-center transition-all duration-300
                ${(inputText.trim() || selectedImage) && !isLoading
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-200 hover:shadow-indigo-300 scale-100' 
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed scale-95'}
              `}
            >
              {isLoading ? <Loader2 size={22} className="animate-spin" /> : <Send size={22} fill="currentColor" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
